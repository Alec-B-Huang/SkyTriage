import json

def lambda_handler(event, context):
    params = {p["name"]: p["value"] for p in event.get("parameters", [])}
    damage_class = params.get("damage_class", "major")
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": json.dumps({
                            "programs": [
                                {"name": "FEMA Individual Assistance", "eligible": True, "max_amount": "$43,900"},
                                {"name": "SBA Disaster Loan", "eligible": damage_class in ["major", "destroyed"], "max_amount": "$200,000"},
                                {"name": "FEMA Rental Assistance", "eligible": damage_class == "destroyed", "max_amount": "$3,000"}
                            ],
                            "damage_class": damage_class
                        })
                    }
                }
            }
        }
    }
