import json

def lambda_handler(event, context):
    image_url = event.get("parameters", [{}])[0].get("value", "")
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": event.get("function"),
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": json.dumps({
                            "damage_class": "major",
                            "confidence": 0.87,
                            "image_url": image_url
                        })
                    }
                }
            }
        }
    }
